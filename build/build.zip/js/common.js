"use strict";
"use strict";

/* eslint-disable eqeqeq */
$('.js-open-modal').click(function (e) {
  e.preventDefault();
  $('.modal').hide();
  var modal = e.target.getAttribute('href') != null ? e.target.getAttribute('href') : e.target.parentElement.getAttribute('href');
  $('body').addClass("hidden");
  $('.header').addClass('over');
  $("[data-type=\"".concat(modal, "\"]")).fadeIn();
});
$(window).click(function (e) {
  if (e.target.classList.contains('modal') && e.target.style.display == 'block') {
    $('.modal').fadeOut();
    $('body').removeClass('hidden');
  }
});
$('.modal__close').click(function (e) {
  $('.modal').fadeOut();
  $('body').removeClass('hidden');
  $('.header').removeClass('over');
});
$('.success__close').click(function (e) {
  $('.modal').fadeOut();
  $('.success').fadeOut();
  $('body').removeClass('hidden');
  $('.header').removeClass('over');
});
$('select').select2({
  minimumResultsForSearch: Infinity,
  width: 'style',
  selectOnClose: true
});
$('.modal__hidden').change(function () {
  $(this).parents('.modal__addfile').addClass('add');
  $('.modal__file-name').text(this.files[0].name);
});
$('.modal__file-change').click(function (e) {
  if ($('.modal__addfile').hasClass('add')) {
    $('.modal__addfile').removeClass('add');
    $('.modal__hidden').val(null);
    $('.modal__file-name').text('Прикрепить файл');
  } else {
    $('.modal__hidden').trigger('click');
  }
});
$('.callback__field, .modal__field').keyup(function () {
  if ($(this).val() == '' || $(this).val() == '+7(___) ___-__-__') {
    $(this).removeClass('val');
  } else {
    $(this).addClass('val');
  }
});
$('.up').click(function () {
  $('html, body').animate({
    scrollTop: 0
  }, 1000);
});
$(window).on('scroll load', function () {
  var up = document.querySelector('.up');

  if (window.pageYOffset > window.innerHeight / 2) {
    up.classList.add('visible');
  } else {
    up.classList.remove('visible');
  }

  if (window.innerWidth < 1600) {
    var raz = window.pageYOffset + $('.footer').outerHeight(true) + window.innerHeight / 2;

    if (raz > $('.footer').offset().top) {
      up.style.bottom = '25vw';
    } else {
      up.style.bottom = "6vw ";
    }
  }
}); // $('input[type="tel"]').mask('+7(999) 999-99-99', { autoclear: false });

var contentSlider = new Swiper('.content .swiper-container', {
  speed: 400,
  loop: true,
  slidesPerView: 1,
  breakpoints: {
    1024: {
      allowTouchMove: true
    }
  },
  pagination: {
    el: '.swiper-pagination',
    clickable: true,
    renderBullet: function renderBullet(index, className) {
      var numb;

      if (index < 9) {
        numb = '0' + (index + 1);
      } else {
        numb = index++;
      }

      return '<span class="' + className + '">' + numb + '</span>';
    }
  }
});

function phone_mask() {
  $.mask.definitions['9'] = '';
  $.mask.definitions['d'] = '[0-9]';
  $("input[type=tel]").mask("+7 ddd ddd-dd-dd");
  var input = document.querySelectorAll("[type=tel]");
  input.forEach(function (item) {
    if (!item.parentElement.classList.contains('iti')) {
      window.intlTelInput(item, {
        autoHideDialCode: false,
        autoPlaceholder: "aggressive",
        placeholderNumberType: "MOBILE",
        preferredCountries: ['ru'],
        utilsScript: "/libs/intl/js/utils.js",
        customPlaceholder: function customPlaceholder(selectedCountryPlaceholder, selectedCountryData) {
          if (selectedCountryData.dialCode == 7) {
            return '+ ' + selectedCountryPlaceholder.replace(/[0-9]/g, '_');
          } else {
            return '+' + selectedCountryData.dialCode + ' ' + selectedCountryPlaceholder.replace(/[0-9]/g, '_');
          }
        }
      });
    }
  });
  $('input[type="tel"]').on("close:countrydropdown", function (e, countryData) {
    $(this).val('');
    $(this).mask($(this).attr('placeholder').replace(/[_]/g, 'd'));
  });
}

phone_mask();
var isValid;
var check;
var pattern = /^[a-z0-9_-]+@[a-z0-9-]+\.([a-z]{1,6}\.)?[a-z]{2,6}$/i;
$('input[name="email"]').blur(function () {
  if (!this.value.match(pattern) && this.value != '') {
    this.classList.add('error');
    isValid = false;
  }
});
$('form').submit(function (e) {
  e.preventDefault();
  var $form = $(this);
  $form.find('.required').each(function (index, elem) {
    if (elem.value === '') {
      elem.classList.add('error');
      isValid = false;
    } else {
      isValid = true;
      elem.classList.remove('error');
    }
  });

  if (!$form.find('.callback__hidden, .modal__hidden').prop('checked')) {
    // eslint-disable-next-line no-unused-expressions
    !$form.find('.callback__hidden, .modal__hidden').addClass('error');
    check = false;
  } else {
    $('.callback__hidden, .modal__hidden').removeClass('error');
    check = true;
  }

  if (isValid !== false && check) {
    setTimeout(function () {
      $form.find('.callback__field, .modal__field').each(function (index, elem) {
        elem.classList.remove('val');
      });
      $('.modal').fadeOut();
      $form.trigger('reset');
      $('body').addClass("hidden");
      $('.header').addClass('over');
      $('.success').fadeIn();
    }, 500);
  }
});
"use strict";

var abTitleTop = $('.about-top__title');
var abTitle = $('.about__title');
var abTitleTopStatus = true;
var abTitleStatus = true;

function loadAbTitleTop() {
  if (abTitleTop.length) {
    var se = window.pageYOffset > abTitleTop.offset().top - $(window).height() + 200;

    if (se && abTitleTopStatus) {
      abTitleTopStatus = false;
      $(abTitleTop).find('p').each(function (index) {
        var _this = this;

        setTimeout(function () {
          $(_this).addClass('visible');
        }, index * 200);
      });
      setTimeout(function () {
        $(abTitleTop).find('span').each(function (index) {
          var _this2 = this;

          setTimeout(function () {
            $(_this2).addClass('loading');
          }, index * 2000);
        });
      }, 1500);
    }
  }
}

function loadabTitle() {
  if (abTitle.length) {
    var se = window.pageYOffset > abTitle.offset().top - $(window).height() + 200;

    if (se && abTitleStatus) {
      abTitleStatus = false;
      $(abTitle).find('p').each(function (index) {
        var _this3 = this;

        setTimeout(function () {
          $(_this3).addClass('visible');
        }, index * 200);
      });
      setTimeout(function () {
        $(abTitle).find('span').each(function (index) {
          var _this4 = this;

          setTimeout(function () {
            $(_this4).addClass('loading');
          }, index * 2000);
        });
      }, 1500);
    }
  }
}

window.addEventListener('DOMContentLoaded', function () {
  loadAbTitleTop();
  loadabTitle();
});
window.addEventListener('scroll', function () {
  loadAbTitleTop();
  loadabTitle();
});
"use strict";
"use strict";

var brands = new Swiper('.brands__slider .swiper-container', {
  speed: 400,
  loop: true,
  slidesPerView: 7,
  slidesOffsetAfter: 0,
  centeredSlides: true,
  breakpoints: {
    575: {
      slidesPerView: 'auto',
      spaceBetween: 20
    },
    1023: {
      slidesPerView: 3,
      spaceBetween: 20
    },
    1200: {
      slidesPerView: 4
    },
    1600: {
      slidesPerView: 5
    }
  }
});
"use strict";
"use strict";

$(window).on('scroll load', function () {
  var head = document.querySelector('.header');

  if (window.pageYOffset > 50) {
    head.classList.add('fix');
  } else {
    head.classList.remove('fix');
  }
});
window.addEventListener('resize', function () {
  if ($('.burger').hasClass('open')) {
    $('.burger').removeClass('open');
    $('.nav-mobile').slideUp();
    $('body').removeAttr('style');
  }
});
$('.burger').click(function () {
  if (!$('.burger').hasClass('open')) {
    $('.burger').addClass('open');
    $('.nav-mobile').slideDown();
    $('body').css({
      'height': '100vh',
      'overflow': 'hidden'
    });
  } else {
    $('.burger').removeClass('open');
    $('.nav-mobile').slideUp();
    $('body').removeAttr('style');
  }
});
/* eslint-disable no-plusplus */

/* eslint-disable no-unused-expressions */

/* eslint-disable no-sequences */

/* eslint-disable no-undef */

/* eslint-disable no-use-before-define */

var cx;
var cy;
var mouseX;
var mouseY;
var posX;
var posY;
var clientX;
var clientY;
var dx;
var dy;
var tiltx;
var tilty;
var request;
var radius;
var degree;
document.addEventListener('DOMContentLoaded', function () {
  var body = document.querySelector('body');
  cx = window.innerWidth / 2;
  cy = window.innerHeight / 2;
  body.addEventListener('mousemove', function (e) {
    clientX = e.pageX;
    clientY = e.pageY;
    request = requestAnimationFrame(updateMe);
    mouseCoords(e);
    cursor.classList.remove('hidden'); // follower.classList.remove('hidden');
  });

  function updateMe() {
    dx = clientX - cx;
    dy = clientY - cy;
    tiltx = dy / cy;
    tilty = dx / cx;
    radius = Math.sqrt(Math.pow(tiltx, 2) + Math.pow(tiltx, 2));
    degree = radius * 12;
  }

  var cursor = document.getElementById('cursor'); // const follower = document.getElementById('aura');

  var links = document.getElementsByTagName('a');
  var button = document.getElementsByTagName('button');
  mouseX = 0, mouseY = 0, posX = 0, posY = 0;

  function mouseCoords(e) {
    mouseX = e.pageX;
    mouseY = e.pageY;
  }

  gsap.to({}, 0.01, {
    repeat: -1,
    onRepeat: function onRepeat() {
      posX += (mouseX - posX) / 5;
      posY += (mouseY - posY) / 5;
      gsap.set(cursor, {
        css: {
          left: mouseX,
          top: mouseY
        }
      }); // gsap.set(follower, {
      //   css: {
      //     left: posX - 24,
      //     top: posY - 24,
      //   },
      // });
    }
  });

  for (var i = 0; i < links.length; i++) {
    links[i].addEventListener('mouseover', function () {
      cursor.classList.add('active'); // follower.classList.add('active');
    });
    links[i].addEventListener('mouseout', function () {
      cursor.classList.remove('active'); // follower.classList.remove('active');
    });
  }

  for (var _i = 0; _i < button.length; _i++) {
    button[_i].addEventListener('mouseover', function () {
      cursor.classList.add('active'); // follower.classList.add('active');
    });

    button[_i].addEventListener('mouseout', function () {
      cursor.classList.remove('active'); // follower.classList.remove('active');
    });
  }

  body.addEventListener('mouseout', function () {
    cursor.classList.add('hidden'); // follower.classList.add('hidden');
  });
});
"use strict";

if (window.innerWidth > 1200) {
  $('.news-index__line').mouseenter(function () {
    $(this).addClass('active').siblings().removeClass('active');
    $('.news-index__pic').css('display', 'none');
    $('.news-index__pic').eq($(this).index()).fadeIn(200);
  });
} else {
  $('.news-index__line').click(function () {
    $(this).addClass('active').siblings().removeClass('active');
    $('.news-index__pic').css('display', 'none');
    $('.news-index__pic').eq($(this).index()).fadeIn(200);

    if (window.innerWidth < 575) {
      $('.news-index__content').animate({
        scrollLeft: ($(this).width() + 25) * $(this).index()
      }, 500);
    }
  });
}

var newsSlider = new Swiper('.news-page .swiper-container', {
  speed: 400,
  loop: true,
  slidesPerView: 1,
  breakpoints: {
    1024: {
      allowTouchMove: true
    }
  },
  pagination: {
    el: '.swiper-pagination',
    clickable: true,
    renderBullet: function renderBullet(index, className) {
      var numb;

      if (index < 9) {
        numb = '0' + (index + 1);
      } else {
        numb = index++;
      }

      return '<span class="' + className + '">' + numb + '</span>';
    }
  }
});
"use strict";
"use strict";

var vantage = new Swiper('.vnt .swiper-container', {
  speed: 400,
  loop: true,
  slidesPerView: 1,
  autoplay: true,
  effect: 'fade',
  fadeEffect: {
    crossFade: true
  },
  breakpoints: {
    1024: {
      allowTouchMove: true
    }
  },
  pagination: {
    el: '.vnt__pagination',
    clickable: true,
    renderBullet: function renderBullet(index, className) {
      var numb;

      if (index < 9) {
        numb = '0' + (index + 1);
      } else {
        numb = index++;
      }

      return '<span class="' + className + '">' + numb + '</span>';
    }
  }
});
var target_block = $('.step');
var blockStep = true;
window.addEventListener('scroll', function () {
  // eslint-disable-next-line camelcase
  if (target_block.length) {
    var se = window.pageYOffset > target_block.offset().top - $(window).height() / 2;

    if (se && blockStep) {
      blockStep = false;
      var comma_separator_number_step = $.animateNumber.numberStepFactories.separator('');
      $(target_block).find('.step__numb').each(function () {
        var numb_end = $(this).find('span').data('numb');
        $(this).find('span').animateNumber({
          number: numb_end,
          easing: 'easeInQuad',
          numberStep: comma_separator_number_step
        }, 4000);
      });
    }
  }
});